package com.example.mycontact;




public class konfigurasi {

    public static final String URL_ADD = "http://10.0.2.2:8080/mycontact/tambah.php";
    public static final String URL_GET_ALL = "http://10.0.2.2:8080/mycontact/tampil_semua.php";
    public static final String URL_GET_CNT = "http://10.0.2.2:8080/mycontact/tampil_contact.php?id=";
    public static final String URL_UPDATE_CNT = "http://10.0.2.2:8080/mycontact/update.php";
    public static final String URL_DELETE_CNT = "http://10.0.2.2:8080/mycontact/delete.php?id=";

    public static final String KEY_CNT_ID = "id";
    public static final String KEY_CNT_NAMA = "nama";
    public static final String KEY_CNT_NOMOR = "nomor";
    public static final String KEY_CNT_EMAIL = "email";
    public static final String KEY_CNT_ALAMAT = "alamat";

    public static final String TAG_JSON_ARRAY = "result";
    public static final String TAG_ID = "id";
    public static final String TAG_NAMA = "nama";
    public static final String TAG_NOMOR = "nomor";
    public static final String TAG_EMAIL = "email";
    public static final String TAG_ALAMAT = "alamat";


    public static final String CNT_ID = "cnt_id";
}
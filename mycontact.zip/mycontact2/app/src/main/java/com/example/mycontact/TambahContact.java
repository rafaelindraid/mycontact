package com.example.mycontact;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;

public class TambahContact extends AppCompatActivity implements View.OnClickListener{

    //Dibawah ini merupakan perintah untuk mendefinikan View
    private EditText enama;
    private EditText enomor;
    private EditText eemail;
    private EditText ealamat;

    private Button buttonAdd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah);

        //Inisialisasi dari View
        enama = (EditText) findViewById(R.id.editTextName);
        enomor = (EditText) findViewById(R.id.editTextNomor);
        eemail = (EditText) findViewById(R.id.editTextEmail);
        ealamat = (EditText) findViewById(R.id.editTextAlamat);
        buttonAdd = (Button) findViewById(R.id.buttonAdd);

        buttonAdd.setOnClickListener(this);

    }

    private void addContact(){
        final String nama = enama.getText().toString().trim();
        final String nomor = enomor.getText().toString().trim();
        final String email = eemail.getText().toString().trim();
        final String alamat = ealamat.getText().toString().trim();

        class AddContact extends AsyncTask<Void,Void,String> {

            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(TambahContact.this,"Menambahkan...","Tunggu...",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(TambahContact.this,s,Toast.LENGTH_LONG).show();
            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String,String> params = new HashMap<>();
                                params.put(konfigurasi.KEY_CNT_NAMA,nama);
                params.put(konfigurasi.KEY_CNT_NOMOR,nomor);
                params.put(konfigurasi.KEY_CNT_EMAIL,email);
                params.put(konfigurasi.KEY_CNT_ALAMAT,alamat);

                RequestHandler rh = new RequestHandler();
                String res = rh.sendPostRequest(konfigurasi.URL_ADD, params);
                return res;
            }
        }
        AddContact ae = new AddContact();
        ae.execute();
    }

    @Override
    public void onClick(View v) {
        if(v == buttonAdd){
            addContact();
            startActivity(new Intent(TambahContact.this,Tampilsemuacontact.class));
        }


    }
}
package com.example.mycontact;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class TampilContact extends AppCompatActivity implements View.OnClickListener{

    private EditText enama;
    private EditText enomor;
    private EditText eemail;
    private EditText ealamat;
    private Button bedit,bhapus,btnon,btncancel;
    private LinearLayout btpesan,btvideo,btmail,bttelp;

    private String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tampil_kontak);

        EditText eid = (EditText) findViewById(R.id.editTextId);
        enama = (EditText) findViewById(R.id.editTextName);
        enomor = (EditText) findViewById(R.id.editTextNomor);
        eemail = (EditText) findViewById(R.id.editTextEmail);
        ealamat = (EditText) findViewById(R.id.editTextAlamat);

        bedit = (Button) findViewById(R.id.buttonUpdate);
        bhapus = (Button) findViewById(R.id.buttonDelete);
        btnon = (Button) findViewById(R.id.btnon);


        btmail = findViewById(R.id.btmail);
        bttelp = findViewById(R.id.bttelp);
        btvideo = findViewById(R.id.btvideo);
        btpesan = findViewById(R.id.btpesan);


        bedit.setOnClickListener(this);
        bhapus.setOnClickListener(this);
        btnon.setOnClickListener(this);

        btpesan.setOnClickListener(this);
        btmail.setOnClickListener(this);
        bttelp.setOnClickListener(this);


        id = getIntent().getStringExtra(konfigurasi.CNT_ID);
        eid.setText(id);
        getContact();
    }

    private void getContact(){
        class GetContact extends AsyncTask<Void,Void,String> {

            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(
                        TampilContact.this,"Mengambil Data",
                        "Tunggu Sebentar...",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                showContact(s);
            }

            @Override
            protected String doInBackground(Void... voids) {
                RequestHandler rh = new RequestHandler();
                return rh.sendGetRequestParam(konfigurasi.URL_GET_CNT,id);
            }
        }
        new GetContact().execute();
    }

    private void showContact(String json){
        try {

            JSONObject jsonObject = new JSONObject(json);
            JSONArray result = jsonObject.getJSONArray(konfigurasi.TAG_JSON_ARRAY);
            JSONObject c = result.getJSONObject(0);
            enama.setText(c.getString(konfigurasi.TAG_NAMA));
            enomor.setText(c.getString(konfigurasi.TAG_NOMOR));
            eemail.setText(c.getString(konfigurasi.TAG_EMAIL));
            ealamat.setText(c.getString(konfigurasi.TAG_ALAMAT));

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void updateContact(){
        final String nama = enama.getText().toString().trim();
        final String nomor = enomor.getText().toString().trim();
        final String email = eemail.getText().toString().trim();
        final String alamat = ealamat.getText().toString().trim();

        class UpdateContact extends AsyncTask<Void,Void,String>{

            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(
                        TampilContact.this,"Mengubah",
                        "Tunggu Sebentar...",false,false
                );

            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(TampilContact.this, s, Toast.LENGTH_SHORT).show();
            }

            @Override
            protected String doInBackground(Void... voids) {

                HashMap<String,String> map = new HashMap<>();
                map.put(konfigurasi.KEY_CNT_ID,id);
                map.put(konfigurasi.KEY_CNT_NAMA,nama);
                map.put(konfigurasi.KEY_CNT_NOMOR,nomor);
                map.put(konfigurasi.KEY_CNT_EMAIL,email);
                map.put(konfigurasi.KEY_CNT_ALAMAT,alamat);
                RequestHandler rh = new RequestHandler();
                return rh.sendPostRequest(konfigurasi.URL_UPDATE_CNT,map);

            }
        }

        new UpdateContact().execute();
    }

    private void deleteContact(){
        class DeleteContact extends AsyncTask<Void,Void,String>{

            ProgressDialog progressDialog;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = ProgressDialog.show(
                        TampilContact.this,"Menghapus Data",
                        "Tunggu Sebentar",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
                Toast.makeText(TampilContact.this, s, Toast.LENGTH_SHORT).show();
            }

            @Override
            protected String doInBackground(Void... voids) {
                RequestHandler rh = new RequestHandler();
                return rh.sendGetRequestParam(konfigurasi.URL_DELETE_CNT,id);
            }
        }

        new DeleteContact().execute();
    }

    private void confirmDelete(){
        new AlertDialog.Builder(TampilContact.this)
                .setMessage("Hapus data pegawai ini ?")
                .setTitle("KONFIRMASI")
                .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        deleteContact();
                        startActivity(new Intent(TampilContact.this,Tampilsemuacontact.class));
                    }
                })
                .setNegativeButton("Tidak",null)
                .show();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.buttonUpdate:
                updateContact();
                Intent intent = new Intent(this,Tampilsemuacontact.class);
                startActivity(intent);
                break;
            case R.id.btnon:
                enama.setEnabled(true);
                enomor.setEnabled(true);
                eemail.setEnabled(true);
                ealamat.setEnabled(true);
                btnon.setVisibility(View.GONE);
                bedit.setEnabled(true);

                break;
            case R.id.buttonDelete:
                confirmDelete();
                break;
            case R.id.btmail:
                Toast.makeText(this, "kamu tekan Btn Mail", Toast.LENGTH_SHORT).show();
                break;
            case R.id.btpesan:
                Toast.makeText(this, "kamu tekan Btn Pesab", Toast.LENGTH_SHORT).show();
                break;
            case R.id.btvideo:
                Toast.makeText(this, "kamu tekan Btn Video", Toast.LENGTH_SHORT).show();
                break;
            case R.id.bttelp:
                Toast.makeText(this, "kamu tekan Btn Telp", Toast.LENGTH_SHORT).show();
                break;

        }

    }
}
